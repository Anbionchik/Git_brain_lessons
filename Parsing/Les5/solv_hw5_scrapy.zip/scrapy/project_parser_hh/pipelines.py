# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from pymongo import MongoClient


class ProjectParserHhPipeline:
    def __init__(self):
        client = MongoClient('localhost', 27017)
        self.mongobase = client.vacancies_python_hh


    def process_item(self, item, spider):

        item["salary"] = self.clean_salary(list_salary=item["salary"])
        
        collection = self.mongobase[spider.name]
        collection.insert_one(item)

        return item

    def clean_salary(self, list_salary):
        min_salary = None
        max_salary = None
        currency_salary = None
        tax_salary = None
        
        for i in range(len(list_salary) - 1):
            if list_salary[i] == 'от ':
                min_salary = int(list_salary[i + 1].replace('\xa0', ''))
            elif list_salary[i] == 'до ':
                max_salary = int(list_salary[i + 1].replace('\xa0', ''))
        if min_salary or max_salary:
            currency_salary = list_salary[-3]
            tax_salary = list_salary[-1]

        return {
            'min_salary': min_salary,
            'max_salary': max_salary,
            'currency_salary': currency_salary,
            'tax_salary': tax_salary,
        }
